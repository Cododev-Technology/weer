public class MultiThread {
    public static void main(String[] args) throws InterruptedException {
        Thread[] threads = new Thread[12];

        // Spawn 12 system level threads
        for (int i = 0; i < 12; i++) {
            threads[i] = new Thread(() -> {
                // Run this in each of the threads
                while (true) {}
            });
            threads[i].start();
        }

        for (Thread t : threads) {
            t.join();
        }
    }
}
