public class SingleThread {
    public static void main(String[] args) {
        // Run on a single thread
        while (true) {}
    }
}
