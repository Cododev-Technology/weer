package main

func main() {
	// Spawn 12 system level threads
	for i := 0; i < 12; i++ {
		go func() {
			// Run this in each of the threads
			for {
			}
		}()
	}
	select {}
}
