package main

func main() {
	// Run on a single thread
	for {
	}
}
