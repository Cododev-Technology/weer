// Run on a single thread
while true {}

