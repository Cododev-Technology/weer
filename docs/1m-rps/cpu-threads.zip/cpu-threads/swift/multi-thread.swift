import Foundation

// Spawn 12 system level threads
var i = 0
while i < 12 {
    Thread {
        // Run this in each of the threads
        while true {}
    }.start()
    
    i += 1
}

RunLoop.main.run()
