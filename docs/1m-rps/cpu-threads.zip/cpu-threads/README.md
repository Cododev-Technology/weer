# CPU Utilization & Threads

Choose whatever language you want, and run and monitor your system resources.

## Run

**Node.js**

```
node multi-thread.js
```

**Go**

```
go run multi-thread.go
```

**Swift**

```
swift multi-thread.swift
```

**Rust**

```
rustc multi-thread.rs -o app && ./app
```

**C**

```
gcc multi-thread.c -lpthread -o app && ./app
```

**Java**

```
java MultiThread.java
```
