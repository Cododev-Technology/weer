#include <pthread.h>

// Run this in each of the threads
void *run(void *arg) {
    while (1) {}
}

int main() {
    pthread_t threads[12];

    // Spawn 12 system level threads
    for (int i = 0; i < 12; i++) {
        pthread_create(&threads[i], NULL, run, NULL);
    }

    for (int i = 0; i < 12; i++) {
        pthread_join(threads[i], NULL);
    }
}
