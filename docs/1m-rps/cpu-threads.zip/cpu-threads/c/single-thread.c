int main() {
    // Run on a single thread
    while (1) {}
}
