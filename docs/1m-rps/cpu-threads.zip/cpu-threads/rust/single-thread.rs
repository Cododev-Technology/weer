fn main() {
    // Run on a single thread
    loop {}
}
