use std::thread;

fn main() {
    // Spawn 12 system level threads
    let handles: Vec<_> = (0..12)
        .map(|_| {
            thread::spawn(|| {
                // Run this in each of the threads
                loop {}
            })
        })
        .collect();

    for h in handles {
        h.join().unwrap();
    }
}
